=== Xcodes Team Member ===
Contributors: alexmehedy
Tags: xcodes team member,team member,hosttier,alexmehedy
Donate link: https://www.buymeacoffee.com/alexmehedy
Requires at least: 5.2
Requires PHP: 7.2
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Xcodes team member  is an easy, responsive, user-friendly WordPress Team member plugin. It has  easy to use via shortcode system.

== Description ==
FEATURES
------------------------
Fully Responsive
Easy Shortcode 
User-Friendly Sorting System
Custom Breakpoints

YOU CAN CHANGES SETTINGS
---------------------------------------------------------------
Color Theme – You can changes color theme.
Hover Color – You can changes hover color.
Add Sub Title  – You can Add Sub Title  .
Add Title  – You can Add Title.



USAGE
-----------------------
Go to your Dashboard after installation and navigate to “Team Member>> Xcode Team setting” to configure the xcodes team member.
* Image size must be usages 400*400 for better view


== Frequently Asked Questions ==
Can it possible to use throw shordcode?
yes

Could it possible to places this Tem meber on post or page?
yes

== Screenshots ==
1. Screenshot1.png
2. Screenshot2.png
3. Screenshot3.png